x = [1 ;2 ;3 ;4 ;5 ;6];
y = [3 ;1 ;2 ;4 ;5 ;1];
plot(x,y,'r')

xlabel('...X...');
ylabel('...Y...');
title('Ploting Graph');